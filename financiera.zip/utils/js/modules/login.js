const loginModule = (()=>{
    'use strict'
    const access_login = ( usrname, pass ) => {
        let a = funcionPrueba( name );
        console.log( a ); 
    }

    return{
        access: access_login   
    };
    
    
})();

